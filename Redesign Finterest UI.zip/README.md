
  # Redesign Finterest UI

  This is a code bundle for Redesign Finterest UI. The original project is available at https://www.figma.com/design/trtHgDQVCfv3f01rDpuCzM/Redesign-Finterest-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  